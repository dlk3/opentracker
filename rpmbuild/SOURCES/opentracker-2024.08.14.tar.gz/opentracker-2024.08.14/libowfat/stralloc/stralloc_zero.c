#include "stralloc.h"

void stralloc_zero(stralloc* sa) {
  sa->len=0;
}
