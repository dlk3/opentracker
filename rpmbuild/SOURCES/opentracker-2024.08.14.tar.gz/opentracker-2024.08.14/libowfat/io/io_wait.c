#include "io_internal.h"

void io_wait() {
  io_waituntil2(-1);
}
