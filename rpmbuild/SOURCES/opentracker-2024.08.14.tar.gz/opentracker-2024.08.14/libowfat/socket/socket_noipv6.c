int noipv6=0;
